import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn.neighbors as skl_nb
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, make_scorer, recall_score, fbeta_score
from sklearn.model_selection import GridSearchCV

df = pd.read_csv("training_data_ht2025.csv")

df['high_demand'] = (df['increase_stock'] == 'high_bike_demand').astype(int)

# Remake hour and week feature (cyclic)
df["hour_sin"] = np.sin(2*np.pi*df["hour_of_day"]/24)
df["hour_cos"] = np.cos(2*np.pi*df["hour_of_day"]/24)

df["dow_sin"] = np.sin(2*np.pi*df["day_of_week"]/7)
df["dow_cos"] = np.cos(2*np.pi*df["day_of_week"]/7)

df["month_sin"] = np.sin(2*np.pi*df["month"]/12)
df["month_cos"] = np.cos(2*np.pi*df["month"]/12)

# non-linear in weather
df["temp_humidity_index"] = df["temp"]*(1-df["humidity"]/100)

# Drop old non-cyclic hour,day,month
df = df.drop(["hour_of_day","day_of_week","month"], axis=1)

# other features to remove
df = df.drop(["snow","snowdepth","dew","windspeed","cloudcover","holiday"],axis=1)

from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split

df = df.drop(['increase_stock'],axis=1)

features = df.drop(columns = ['high_demand'])
X_train, X_test, y_train, y_test = train_test_split(features, df['high_demand'], test_size=0.2, random_state=42)

smote = SMOTE(sampling_strategy="auto",random_state=42)
X_train_features, y_train_resampled = smote.fit_resample(X_train,y_train)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_features)
X_test_scaled = scaler.transform(X_test)

fbeta_scorer = make_scorer(fbeta_score,beta=2, pos_label=1)

params = {
    "n_neighbors": range(1,50),
    "weights":["uniform","distance"],
    "p":[1,2]
}

grid = GridSearchCV(
    skl_nb.KNeighborsClassifier(),
    params,
    cv=10,
    scoring=fbeta_scorer
)

grid.fit(X_train_scaled, y_train_resampled)

best_model = grid.best_estimator_

print("Best parameters:", grid.best_params_)
print("Best score:", grid.best_score_)

y_pred = best_model.predict(X_test_scaled)

test_f2 = fbeta_score(y_test,y_pred,beta=2,pos_label=1)
test_accuracy = accuracy_score(y_test,y_pred)

print("ACCURACY",test_accuracy)
print("F2SCORE",test_f2)






















































































































