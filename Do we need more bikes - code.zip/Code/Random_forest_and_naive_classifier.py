import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score, KFold, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
import seaborn as sns
from imblearn.over_sampling import SMOTE
from sklearn.metrics import make_scorer, fbeta_score, accuracy_score, confusion_matrix

data = pd.read_csv("C:/Users/Ebba/Downloads/SML_project_template/training_data_ht2025.csv")
df = pd.DataFrame(data)
df.replace('high_bike_demand', 1, inplace=True)
df.replace('low_bike_demand', 0, inplace=True)

# Making hour, day and month cyclic
df["hour_sin"] = np.sin(2*np.pi*df["hour_of_day"]/24)
df["hour_cos"] = np.cos(2*np.pi*df["hour_of_day"]/24)

df["day_sin"] = np.sin(2*np.pi*df["day_of_week"]/24)
df["day_cos"] = np.cos(2*np.pi*df["day_of_week"]/24)

df["month_sin"] = np.sin(2*np.pi*df["month"]/24)
df["month_cos"] = np.cos(2*np.pi*df["month"]/24)

df = df.drop(columns=["hour_of_day"])
df = df.drop(columns=["day_of_week"])
df = df.drop(columns=["month"])

# Dropping features described in report.
df = df.drop(columns=['snow', 'weekday', 'summertime', 'dew', 'visibility', 'holiday'])

# Dividing the dataset.
X = df.drop(columns = ['increase_stock'])
y = df['increase_stock']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Implements SMOTE to account for the imbalance in the dataset.
X_train_res, y_train_res = SMOTE(sampling_strategy='auto', random_state=42).fit_resample(X_train, y_train)

f2_scorer = make_scorer(fbeta_score, beta=2)

param_grid = {'n_estimators': [100, 200, 400],'max_depth': [None, 10, 20],'min_samples_split': [2, 5, 10],'min_samples_leaf': [1, 2],'bootstrap': [True, False]}

grid = GridSearchCV(RandomForestClassifier(random_state=42),param_grid,scoring=f2_scorer, n_jobs=-1)
grid.fit(X_train_res, y_train_res)
print("Best params:", grid.best_params_)
print("Best F2 score:", grid.best_score_)

classifier = RandomForestClassifier(n_estimators=400, min_samples_leaf=1, min_samples_split=2, bootstrap=False, max_depth=10, random_state=42)
classifier.fit(X_train_res, y_train_res)

y_pred = classifier.predict(X_test)
y_naive = np.ones(len(y_test)) #Naive classifier.

naive_accuracy = accuracy_score(y_test, y_naive)
naive_f2_score = fbeta_score(y_test, y_naive, beta=2)
model_accuracy = accuracy_score(y_test, y_pred)
model_f2_score = fbeta_score(y_test, y_pred, beta=2)


# F2-score and accuracy for random forest classifier.
print(f'F2 score - random forest classifier: {model_f2_score * 100:.2f}%')
print(f'Accuracy - random forest classifier: {model_accuracy * 100:.2f}%')
# F2-score and accuracy for the naive classifier.
print(f'F2 score - naive classifier: {naive_f2_score * 100:.2f}%')
print(f'Accuracy - naive classifier: {naive_accuracy * 100:.2f}%')

# Using cross-validation to evaluate performance.
splits = 10
kf = KFold(n_splits=splits, shuffle=True, random_state=42)
cross_val_results_f2 = cross_val_score(classifier, X_train, y_train, cv=kf, scoring=f2_scorer)
cross_val_results_acc = cross_val_score(classifier, X_train, y_train, cv=kf, scoring='accuracy')

# NOTE: This is not the values that are compared to the rest of the models.
print("Cross-Validation Results (F2-score):")
for i in range(splits):
    print(f"  Fold {i+1}: F2 - {cross_val_results_f2[i] * 100:.2f}%, Accuracy - {cross_val_results_acc[i] * 100:.2f}%")
print(f'Mean F2-score: {cross_val_results_f2.mean()* 100:.2f}%')
print(f'Mean Accuracy: {cross_val_results_acc.mean()* 100:.2f}%')

# Heat map for the random forest classifier.
conf_matrix_pred = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix_pred, annot=True, fmt='g', cmap='Blues', cbar=False)
plt.title('Confusion Matrix Heatmap - random forest classifier')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()

# Heat map for the naive classifier.
conf_matrix_naive = confusion_matrix(y_test, y_naive)
sns.heatmap(conf_matrix_naive, annot=True, fmt='g', cmap='Reds', cbar=False)
plt.title('Confusion Matrix Heatmap - naive classifier')
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.show()