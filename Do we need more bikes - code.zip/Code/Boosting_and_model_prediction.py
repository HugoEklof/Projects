# Boosting

import pandas as pd
import numpy as np

df = pd.read_csv(r"training_data_ht2025.csv")

# Assigning -1 and 1 to bike demand
df["increase_stock"] = df["increase_stock"].map({"low_bike_demand":-1, "high_bike_demand":1})

# Removing "snow" column since every value is zero
df = df.drop(columns=["snow"])

# Removing additional columns due to dependency
df = df.drop(columns=["weekday"])
df = df.drop(columns=["summertime"])
df = df.drop(columns=["dew"])
df = df.drop(columns=["visibility"])
df = df.drop(columns=["holiday"])

# Making hour, day and month cyclic

df["hour_sin"] = np.sin(2*np.pi*df["hour_of_day"]/24)
df["hour_cos"] = np.cos(2*np.pi*df["hour_of_day"]/24)

df["day_sin"] = np.sin(2*np.pi*df["day_of_week"]/7)
df["day_cos"] = np.cos(2*np.pi*df["day_of_week"]/7)

df["month_sin"] = np.sin(2*np.pi*df["month"]/12)
df["month_cos"] = np.cos(2*np.pi*df["month"]/12)

df = df.drop(columns=["hour_of_day"])
df = df.drop(columns=["day_of_week"])
df = df.drop(columns=["month"])

# Boosting class

from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn import tree

class Boosting(BaseEstimator, ClassifierMixin):
    def __init__(self, B=10, m=1): #Default values - these are overwritten as the gridsearch looks for better parameters
        self.B = B
        self.m = m
    
    def fit(self, X, y):

        X = np.asarray(X)
        y = np.asarray(y).flatten()

        n = len(y)

        self.stumps = []
        self.alpha_list = np.array([])
        w = np.repeat(1/n, n)
        for b in range(1, self.B+1):
            f_model = tree.DecisionTreeClassifier(max_depth=self.m)
            f_model.fit(X,y, sample_weight=w)
            self.stumps.append(f_model)

            predictions = f_model.predict(X)

            mcs = abs(predictions - y)/2   # number of missclassifications
            E = sum(w*mcs)

            alpha = (1/2)*np.log((1-E)/E)
            self.alpha_list = np.append(self.alpha_list, alpha)

            w = w*np.exp(-alpha*predictions*y)

            w = w/sum(w) # normalizing

        return self

    def predict(self, X):   

        X = np.asarray(X)

        preds = []
        for row in X:
            stump_preds = np.array([
                stump.predict(row.reshape(1, -1))[0]
                for stump in self.stumps
            ])
            
            boost = np.sum(self.alpha_list * stump_preds)
            preds.append(np.sign(boost))

        return preds

from sklearn.model_selection import train_test_split

# Seed: 42
features = df.drop(columns = ['increase_stock'])
X_train, X_test, y_train, y_test = train_test_split(features, df['increase_stock'], test_size=0.2, random_state=42)

# SMOTE
from imblearn.over_sampling import SMOTE

smote = SMOTE(sampling_strategy='auto', random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)

# Grid-search
from sklearn.model_selection import GridSearchCV

model = Boosting()

param_grid = {
    'B': [50, 100, 200, 300],
    'm': [1, 2, 3]
}

# Using F2-scorer
from sklearn.metrics import make_scorer, fbeta_score
fbeta = make_scorer(fbeta_score, beta=2, pos_label=1)

grid = GridSearchCV(
    model,
    param_grid,
    scoring=fbeta,
    cv=10,
    n_jobs=-1
)

grid.fit(X_train_resampled, y_train_resampled)

print("Best params boosting:", grid.best_params_)
print("f2 score boosting:", grid.best_score_)

# Final evaluation
from sklearn.metrics import accuracy_score

best_model = grid.best_estimator_
prediction = best_model.predict(X_test)

test_accuracy = accuracy_score(y_test, prediction)
test_f2 = fbeta_score(y_test, prediction, beta=2, pos_label=1)

print("Final test accuracy:", test_accuracy)
print("Final test f2:", test_f2)

# PREDICTING RESULTS WITH BOOSTING METHOD ON TEST DATA

df = pd.read_csv(r"test_data_fall2025.csv")

# We handle the given data in the same way as we did the training data

df = df.drop(columns=["snow"])
df = df.drop(columns=["weekday"])
df = df.drop(columns=["summertime"])
df = df.drop(columns=["dew"])
df = df.drop(columns=["visibility"])
df = df.drop(columns=["holiday"])

df["hour_sin"] = np.sin(2*np.pi*df["hour_of_day"]/24)
df["hour_cos"] = np.cos(2*np.pi*df["hour_of_day"]/24)

df["day_sin"] = np.sin(2*np.pi*df["day_of_week"]/7)
df["day_cos"] = np.cos(2*np.pi*df["day_of_week"]/7)

df["month_sin"] = np.sin(2*np.pi*df["month"]/12)
df["month_cos"] = np.cos(2*np.pi*df["month"]/12)

df = df.drop(columns=["hour_of_day"])
df = df.drop(columns=["day_of_week"])
df = df.drop(columns=["month"])

# Predict on testing data
prediction_test = best_model.predict(df)

# Convert every -1 to 0
prediction_test = [0 if x == -1 else 1 for x in prediction_test]

# Save the values in a csv file
pd.DataFrame([prediction_test]).to_csv("predictions.csv", index=False, header=False)