import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn.neighbors as skl_nb
#import sklearn
df = pd.read_csv("training_data_ht2025.csv")
df['high_demand'] = (df['increase_stock'] == 'high_bike_demand').astype(int)

hourly = df.groupby("hour_of_day")["high_demand"].mean()
hourly.plot(kind="bar", figsize=(10,5))
plt.title("Average High Bike Demand by Hour of Day")
plt.xlabel("Hour of Day")
plt.ylabel("High Demand Rate")
plt.show()


#HEATMAP
pivot = df.pivot_table(
    values="high_demand",
    index="day_of_week",
    columns="hour_of_day",
    aggfunc="mean"
)

plt.figure(figsize=(12,6))
sns.heatmap(pivot, cmap="viridis")
plt.title("Heatmap of High Demand: Day of Week × Hour")
plt.show()
