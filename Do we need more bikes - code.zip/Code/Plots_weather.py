import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"training_data_ht2025.csv")

# Assigning numerical values to the high/low demand
df["increase_stock"] = df["increase_stock"].map({"low_bike_demand":0, "high_bike_demand":1})

# %% Temperature

ax = df.boxplot(by="increase_stock", column="temp")
  
ax.set_title("") 
plt.suptitle("")
ax.set_xlabel("Bike demand")                 
ax.set_ylabel("Temperature ($^\circ$C)")   
ax.set_xticklabels(["low", "high"])

plt.show()

# %% Precipitation

df_precip = df[df["precip"] > 0]

precip_counts = df_precip["increase_stock"].value_counts()

total_counts = df["increase_stock"].value_counts()

scale = precip_counts/total_counts


print(precip_counts)
print(total_counts)
print(scale)

ax = scale.plot(kind="bar")

ax.set_title("") 
ax.set_xlabel("Bike demand")
ax.set_ylabel("Instances with precip. / total instances (%)")

ax.set_xticklabels(["low", "high"], rotation=0)

plt.show()

# %% Wind speed

ax = df.boxplot(by="increase_stock", column="windspeed")
  
ax.set_title("") 
plt.suptitle("")
ax.set_xlabel("Bike demand")                 
ax.set_ylabel("Wind speed (km/h)")  
ax.set_xticklabels(["low", "high"]) 

plt.show()

# %% Humidity

ax = df.boxplot(by="increase_stock", column="humidity")
  
ax.set_title("") 
plt.suptitle("") 
ax.set_xlabel("Bike demand")                 
ax.set_ylabel("Relative humidity (%)")   
ax.set_xticklabels(["low", "high"])

plt.show()

# %% Snow depth

df_precip = df[df["snowdepth"] > 0]

ct = (df_precip["increase_stock"].value_counts()/1312).reindex([0, 1], fill_value=0)

ax = ct.plot(kind="bar")

ax.set_xlabel("Bike demand")
ax.set_ylabel("Instances with snow d. / total instances (%)")

ax.set_xticklabels(["low", "high"], rotation=0)

plt.show()

# %% Cloud cover

ax = df.boxplot(by="increase_stock", column="cloudcover")

ax.set_title("")  
plt.suptitle("")
ax.set_xlabel("Bike demand")                 
ax.set_ylabel("Cloud cover over city (%)")   
ax.set_xticklabels(["low", "high"])

plt.show()
