import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("C:/Users/Ebba/Downloads/SML_project_template/training_data_ht2025.csv")
df = pd.DataFrame(data)
df.replace('high_bike_demand', 1, inplace=True)
df.replace('low_bike_demand', 0, inplace=True)

# Plots of the distribution of the days when there is high and low demand.
bike_demand_day = df[['day_of_week', 'increase_stock']]
high_bike_day = bike_demand_day[bike_demand_day['increase_stock'] == 1]
low_bike_day = bike_demand_day[bike_demand_day['increase_stock'] == 0]
hist1 = high_bike_day.hist(column='day_of_week', bins=[0, 1, 2, 3, 4, 5, 6, 7], color='red'); plt.title('Day of the week - High demand'); plt.subplot(); plt.show()
hist2 = low_bike_day.hist(column='day_of_week', bins=[0, 1, 2, 3, 4, 5, 6, 7]); plt.title('Day of the week - Low demand'); plt.subplot(); plt.show()

# Plots for demand depending on if it is a holiday or not.
bike_holiday = df[['holiday', 'increase_stock']]
true_holiday = bike_holiday[bike_holiday['holiday'] == 1]
false_holiday = bike_holiday[bike_holiday['holiday'] == 0]
hist3 = true_holiday.hist(column='increase_stock', bins=3, color='red'); plt.title('Demand - Holiday'); plt.subplot(); plt.show()
hist4 = false_holiday.hist(column='increase_stock', bins=3); plt.title('Demand - No holiday'); plt.subplot(); plt.show()
