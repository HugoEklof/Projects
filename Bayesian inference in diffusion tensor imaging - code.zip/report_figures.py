"""
Figures and numbers for the variational inference section and the comparison section of the report.

Produces (in paper/):
  - vi_results.pdf           Figure 2: ELBO trace and the VI posterior summaries
  - comparison_marginals.pdf Figure 4: posterior histograms of S0, MD, FA and angle for MH, VI and Laplace
  - comparison_joint.pdf     Figure 5: joint S0-MD / S0-FA structure and the relative spread of each eigenvalue
and prints:
  - the rows of Table 1 (mean, sd and 95% interval for each method)
  - the numbers quoted in the comparison section (correlations, interval widths, distances to the point estimate)
  - the MH convergence checks (burn-in, quarter means, effective sample sizes)
  - with --timings: the wall-clock time of one uncached fit of each method and the time for 1e5 voxels

The model and inference code is loaded straight from "Project_code_final.ipynb" (only read, never changed),
and all fits are loaded from the disk cache with the same settings as main() and compare_methods.py.

Run from the project folder:  python report_figures.py            (figures and numbers, a few seconds)
                              python report_figures.py --timings  (also the timings, about a minute more)
"""

import json
import sys
import time

NOTEBOOK = "Project_code_final.ipynb"
OUT_DIR = "paper"
N_SAMPLES = 10000     # samples drawn from the VI and Laplace approximations
TIME_METHODS = "--timings" in sys.argv   # time one uncached fit of each method (takes about a minute)

# Same Metropolis-Hastings settings as in main() and compare_methods.py
MH_N_SAMPLES = 50000
MH_GAMMA = 0.01
MH_NU = 2000
MH_BURN_IN = 500


# Load the code cells from the notebook, skipping the pip install, the test cells and main()
with open(NOTEBOOK) as f:
    cells = json.load(f)["cells"]

for cell in cells:
    src = "".join(cell["source"])
    if cell["cell_type"] != "code" or src.lstrip().startswith("!"):
        continue
    if "TEST" in src or "def main(" in src:
        continue
    exec(src, globals())

from scipy.stats import gaussian_kde

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.6,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6, "pdf.fonttype": 42,
})


# Data, DTI point estimate and the three fits (the likelihood class needs gtab as a global)
y, point_estimate, gtab = get_preprocessed_data()
S0_init, evals_init, evecs_init = point_estimate
D_init = compute_D(evals_init, evecs_init).squeeze()
evec_principal = evecs_init[:, 0]

np.random.seed(0)
S0_mh, evals_mh, evecs_mh = metropolis_hastings(MH_N_SAMPLES, MH_GAMMA, MH_NU)
np.random.seed(0)   # VI is fitted from seed 0, as in main()
posterior_vi = variational_inference(S0_init, D_init)
posterior_laplace = laplace_approximation(S0_init, D_init)

np.random.seed(0)
samples = {
    "MH": (S0_mh[MH_BURN_IN:], evals_mh[MH_BURN_IN:], evecs_mh[MH_BURN_IN:]),
    "VI": posterior_vi.rvs(size=N_SAMPLES),
    "Laplace": posterior_laplace.rvs(size=N_SAMPLES),
}

# same colours as compare_methods.py, plus a line style per method so they are not told apart by colour alone
colors = {"MH": "tab:green", "VI": "tab:blue", "Laplace": "tab:orange"}
linestyles = {"MH": "-", "VI": "--", "Laplace": ":"}
labels = {"S0": r"$S_0$", "MD": r"MD ($10^{-4}$ mm$^2$/s)", "FA": "FA", "angle": "Acute angle (deg)"}


def summaries(S0, evals, evecs):
    # eigenvalues are in ascending order for all three methods, so the principal eigenvector is the last column
    angle = np.degrees(np.arccos(np.clip(np.abs(evecs[:, :, 2] @ evec_principal), 0, 1)))
    return {"S0": S0.squeeze(),
            "MD": 1e4 * dti.mean_diffusivity(evals).squeeze(),
            "FA": dti.fractional_anisotropy(evals).squeeze(),
            "angle": angle}


results = {method: summaries(*s) for method, s in samples.items()}
point = {"S0": S0_init, "MD": 1e4 * dti.mean_diffusivity(evals_init), "FA": dti.fractional_anisotropy(evals_init)}


"""
Figure: VI section (ELBO trace + VI posterior summaries)
"""

fig = plt.figure(figsize=(5.5, 2.15))
grid = fig.add_gridspec(2, 4, height_ratios=[0.8, 1], hspace=0.75, wspace=0.35)

ax = fig.add_subplot(grid[0, :])
elbo = posterior_vi.elbo_trace
window = 200
ax.plot(elbo, color="tab:blue", alpha=0.25, linewidth=0.5, label="ELBO estimate ($K=20$)")
ax.plot(np.arange(window - 1, len(elbo)), np.convolve(elbo, np.ones(window) / window, mode="valid"),
        color="black", linewidth=1.2, label=f"moving average ({window} it.)")
ax.set_ylim(np.percentile(elbo, 1), np.max(elbo) + 1)
ax.set_xlabel("Iteration")
ax.set_ylabel("ELBO")
ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), frameon=False, ncol=2)

vi = results["VI"]
for i, quantity in enumerate(["S0", "MD", "FA", "angle"]):
    ax = fig.add_subplot(grid[1, i])
    ax.hist(vi[quantity], bins=60, density=True, color="tab:blue", alpha=0.6, edgecolor="none")
    if quantity in point:
        ax.axvline(point[quantity], color="black", linestyle="--", linewidth=0.8)
    ax.set_xlabel(labels[quantity])
    ax.set_yticks([])
    ax.xaxis.set_major_locator(plt.MaxNLocator(3))

fig.savefig(f"{OUT_DIR}/vi_results.pdf", bbox_inches="tight")
print(f"Saved {OUT_DIR}/vi_results.pdf")


"""
Figure: marginal comparison of the three methods (compact version of comparison_all_methods.png)
"""

fig, axes = plt.subplots(1, 4, figsize=(5.5, 1.55))

for ax, quantity in zip(axes, ["S0", "MD", "FA", "angle"]):
    all_values = np.concatenate([results[m][quantity] for m in results])
    bins = np.linspace(np.percentile(all_values, 0.1), np.percentile(all_values, 99.9), 50)
    for method in results:
        ax.hist(results[method][quantity], bins=bins, density=True, histtype="step",
                color=colors[method], linestyle=linestyles[method], linewidth=1.2, label=method)
    if quantity in point:
        ax.axvline(point[quantity], color="gray", linewidth=0.8, label="DTI estimate")
    ax.set_xlabel(labels[quantity])
    ax.set_yticks([])
    ax.xaxis.set_major_locator(plt.MaxNLocator(3))

axes[0].set_ylabel("Density")
handles, legend_labels = axes[0].get_legend_handles_labels()
fig.legend(handles, legend_labels, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 1.12))
fig.tight_layout()
fig.savefig(f"{OUT_DIR}/comparison_marginals.pdf", bbox_inches="tight")
print(f"Saved {OUT_DIR}/comparison_marginals.pdf")


"""
Figure: joint structure (S0 vs MD, S0 vs FA) and the relative spread of each eigenvalue
"""


def hpd_contour(ax, x, y_, color, linestyle, levels=(0.5, 0.9)):
    # KDE contours enclosing (approximately) the given posterior mass
    kde = gaussian_kde(np.vstack([x, y_]))
    xs = np.linspace(np.percentile(x, 0.2), np.percentile(x, 99.8), 120)
    ys = np.linspace(np.percentile(y_, 0.2), np.percentile(y_, 99.8), 120)
    X, Y = np.meshgrid(xs, ys)
    Z = kde(np.vstack([X.ravel(), Y.ravel()])).reshape(X.shape)
    z_sorted = np.sort(Z.ravel())[::-1]
    mass = np.cumsum(z_sorted) / np.sum(z_sorted)
    thresholds = sorted(z_sorted[np.searchsorted(mass, lvl)] for lvl in levels)
    ax.contour(X, Y, Z, levels=thresholds, colors=color, linestyles=linestyle, linewidths=1.0)


fig, axes = plt.subplots(1, 3, figsize=(5.5, 1.75))
rng = np.random.default_rng(0)

for ax, (qx, qy) in zip(axes[:2], [("S0", "MD"), ("S0", "FA")]):
    for method in results:
        x, y_ = results[method][qx], results[method][qy]
        idx = rng.choice(len(x), size=min(4000, len(x)), replace=False)   # KDE on a subsample for speed
        hpd_contour(ax, x[idx], y_[idx], colors[method], linestyles[method])
    ax.plot(point[qx], point[qy], "x", color="black", markersize=5, markeredgewidth=1.2)
    ax.set_xlabel(labels[qx])
    ax.set_ylabel(labels[qy])

# relative spread (sd / mean) of each ordered eigenvalue
ax = axes[2]
width = 0.26
for j, method in enumerate(results):
    evals = samples[method][1]
    cv = 100 * evals.std(axis=0) / evals.mean(axis=0)
    ax.bar(np.arange(3) + (j - 1) * width, cv[::-1], width=width * 0.9, color=colors[method],
           alpha=0.85, label=method, hatch={"MH": "", "VI": "////", "Laplace": "...."}[method], edgecolor="white")
ax.set_xticks(range(3))
ax.set_xticklabels([r"$\lambda_1$", r"$\lambda_2$", r"$\lambda_3$"])
ax.set_ylabel("sd / mean (%)")

legend_lines = [plt.Line2D([], [], color=colors[m], linestyle=linestyles[m], linewidth=1.2) for m in results]
fig.legend(legend_lines, list(results), loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 1.1))
fig.tight_layout()
fig.savefig(f"{OUT_DIR}/comparison_joint.pdf", bbox_inches="tight")
print(f"Saved {OUT_DIR}/comparison_joint.pdf")


"""
Numbers for the report
"""

print("\nLaTeX table rows: mean (sd) [95% interval]")
fmt = {"S0": "{:.1f}", "MD": "{:.2f}", "FA": "{:.3f}", "angle": "{:.2f}"}
fmt_sd = {"S0": "{:.1f}", "MD": "{:.2f}", "FA": "{:.3f}", "angle": "{:.2f}"}
for quantity in ["S0", "MD", "FA", "angle"]:
    cells_ = []
    for method in results:
        v = results[method][quantity]
        lo, hi = np.percentile(v, [2.5, 97.5])
        f, fs = fmt[quantity], fmt_sd[quantity]
        cells_.append(f"{f.format(v.mean())} ({fs.format(v.std())}) & [{f.format(lo)}, {f.format(hi)}]")
    print(f"{quantity} & " + " & ".join(cells_) + r" \\")

print("\nCorrelations")
for method in results:
    r = results[method]
    print(f"{method:8s} S0-MD {np.corrcoef(r['S0'], r['MD'])[0, 1]:+.2f}   S0-FA {np.corrcoef(r['S0'], r['FA'])[0, 1]:+.2f}"
          f"   MD-FA {np.corrcoef(r['MD'], r['FA'])[0, 1]:+.2f}")

print("\nRelative spread of the eigenvalues (sd / mean, %, largest first)")
for method in results:
    evals = samples[method][1]
    print(f"{method:8s}", np.round(100 * evals.std(axis=0) / evals.mean(axis=0), 1)[::-1])
print(f"VI: sqrt(2 / nu) = {100 * np.sqrt(2 / posterior_vi.df[0]):.1f}%  (nu = {posterior_vi.df[0]:.0f})")

# conditional sd of S0 given D fixed at the DTI estimate, i.e. what a mean-field q(S0) can at most capture
x = np.sqrt(gtab.bvals[:, None]) * gtab.bvecs
A = np.exp(-np.einsum("ij,jk,ik->i", x, D_init, x))
print(f"\nsd of S0 given D = D_DTI: {29 / np.sqrt(np.sum(A**2)):.2f}")
print(f"VI: alpha = {posterior_vi.shape[0]:.0f}, beta = {posterior_vi.scale[0]:.4f}, nu = {posterior_vi.df[0]:.0f}, "
      f"ELBO (mean of last 500 it.) = {posterior_vi.elbo_trace[-500:].mean():.1f}")


def ess(chain):
    # effective sample size from the autocorrelation, summed over Geyer's initial positive sequence
    chain = chain - chain.mean()
    n = len(chain)
    f = np.fft.rfft(chain, 2 * n)
    acf = np.fft.irfft(f * np.conj(f))[:n]
    acf /= acf[0]
    tau = -1.0
    for k in range(0, n - 1, 2):
        pair = acf[k] + acf[k + 1]
        if pair < 0:
            break
        tau += 2 * pair
    return n / tau


print("\nMetropolis-Hastings")
print(f"acceptance rate: {np.mean(np.any(np.diff(evals_mh, axis=0) != 0, axis=1)):.3f}")
for quantity in ["S0", "MD", "FA"]:
    print(f"ESS {quantity}: {ess(results['MH'][quantity]):.0f} of {len(results['MH'][quantity])}")

# burn-in: running means of the start of the chain (in blocks of 500) against the posterior mean after burn-in
full = summaries(S0_mh, evals_mh, evecs_mh)
print(f"\nStart of the chain, block means (posterior mean after burn-in: S0 {results['MH']['S0'].mean():.1f}, "
      f"MD {results['MH']['MD'].mean():.3f}, FA {results['MH']['FA'].mean():.4f})")
for start in range(0, MH_BURN_IN + 1000, 500):
    block = slice(start, start + 500)
    print(f"  {start:5d}-{start + 500:5d}: S0 {full['S0'][block].mean():6.1f}  MD {full['MD'][block].mean():.3f}  "
          f"FA {full['FA'][block].mean():.4f}")

# stationarity: means of the four quarters of the chain after burn-in, in units of the posterior sd
print("Spread of the quarter means after burn-in (max - min, in posterior sd):")
for quantity in ["S0", "MD", "FA"]:
    v = results["MH"][quantity]
    quarter_means = [part.mean() for part in np.array_split(v, 4)]
    print(f"  {quantity}: {(max(quarter_means) - min(quarter_means)) / v.std():.2f}")


"""
Numbers quoted in the comparison section
"""


def width(v):
    lo, hi = np.percentile(v, [2.5, 97.5])
    return hi - lo


print("\nMedian acute angle (deg):", {m: round(float(np.median(results[m]["angle"])), 2) for m in results})

print("\nLaplace compared with MH")
for quantity in ["S0", "MD", "FA", "angle"]:
    a, b = results["MH"][quantity], results["Laplace"][quantity]
    print(f"  {quantity}: mean difference {(b.mean() - a.mean()) / a.std():+.2f} sd, "
          f"95% width ratio {width(b) / width(a):.3f}, upper 97.5% point MH {np.percentile(a, 97.5):.4g} "
          f"Laplace {np.percentile(b, 97.5):.4g}")
pairs = [("S0", "MD"), ("S0", "FA"), ("MD", "FA")]
corr = {m: [np.corrcoef(results[m][p], results[m][q])[0, 1] for p, q in pairs] for m in results}
print("  largest difference in correlation:", f"{np.max(np.abs(np.subtract(corr['MH'], corr['Laplace']))):.3f}")

print("\nVI 95% interval width relative to MH")
for quantity in ["S0", "MD", "FA", "angle"]:
    print(f"  {quantity}: {width(results['VI'][quantity]) / width(results['MH'][quantity]):.3f}")

print("\nPoint estimate relative to each posterior (distance from the mean in sd, inside the 95% interval?)")
for method in results:
    for quantity in point:
        v = results[method][quantity]
        lo, hi = np.percentile(v, [2.5, 97.5])
        print(f"  {method:8s} {quantity}: {(point[quantity] - v.mean()) / v.std():+.2f} sd, "
              f"inside = {bool(lo <= point[quantity] <= hi)}")

if TIME_METHODS:
    # __wrapped__ calls the functions without the disk cache, so the cached results are left untouched
    print("\nWall-clock time for one voxel, and for 1e5 voxels on a single core")
    times = {}
    t = time.time(); laplace_approximation.__wrapped__(S0_init, D_init); times["Laplace"] = time.time() - t
    t = time.time(); metropolis_hastings.__wrapped__(MH_N_SAMPLES, MH_GAMMA, MH_NU); times[f"MH ({MH_N_SAMPLES} it.)"] = time.time() - t
    t = time.time(); variational_inference.__wrapped__(S0_init, D_init); times["VI (10000 it.)"] = time.time() - t
    for method, seconds in times.items():
        print(f"  {method}: {seconds:.2f} s per voxel, {seconds * 1e5 / 3600:.1f} hours = {seconds * 1e5 / 86400:.1f} days")
