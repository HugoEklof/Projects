"""
Scatter plots of the Metropolis-Hastings samples (after burn-in), showing how
S0, mean diffusivity and fractional anisotropy are correlated in the posterior.

The model and MH code is loaded straight from "Project code.ipynb" (only read, never changed),
and the chain is loaded from the disk cache if it has already been run with the same settings.

Run from the project folder:  python plot_mh_scatter.py
"""

import json

NOTEBOOK = "Project code.ipynb"
RECOMPUTE = False     # set to True to ignore the disk cache and rerun the chain

# Same Metropolis-Hastings settings as in main() and compare_methods.py
MH_N_SAMPLES = 50000
MH_GAMMA = 0.01
MH_NU = 2000
MH_BURN_IN = 500


# Load the code cells from the notebook, skipping the pip install, the test cells and main()
with open(NOTEBOOK) as f:
    cells = json.load(f)["cells"]

for cell in cells:
    src = "".join(cell["source"])
    if cell["cell_type"] != "code" or src.lstrip().startswith("!"):
        continue
    if "TEST" in src or "def main(" in src:
        continue
    exec(src, globals())


# Data and DTI point estimate (the likelihood class needs gtab as a global)
y, point_estimate, gtab = get_preprocessed_data()
S0_init, evals_init, evecs_init = point_estimate

np.random.seed(0)
S0_mh, evals_mh, evecs_mh = metropolis_hastings(MH_N_SAMPLES, MH_GAMMA, MH_NU, force_recompute=RECOMPUTE)

samples = {
    "S0": S0_mh[MH_BURN_IN:].squeeze(),
    "Mean diffusivity": dti.mean_diffusivity(evals_mh[MH_BURN_IN:]).squeeze(),
    "Fractional anisotropy": dti.fractional_anisotropy(evals_mh[MH_BURN_IN:]).squeeze(),
}
point = {
    "S0": S0_init,
    "Mean diffusivity": dti.mean_diffusivity(evals_init),
    "Fractional anisotropy": dti.fractional_anisotropy(evals_init),
}

pairs = [("S0", "Mean diffusivity"), ("S0", "Fractional anisotropy"), ("Mean diffusivity", "Fractional anisotropy")]

fig, axes = plt.subplots(1, 3, figsize=(16, 5))

for ax, (qx, qy) in zip(axes, pairs):
    x, y_ = samples[qx], samples[qy]
    ax.scatter(x, y_, s=2, alpha=0.15, color="tab:green", linewidths=0, rasterized=True)
    ax.scatter(point[qx], point[qy], s=80, marker="x", color="black", linewidths=2)

    ax.set_xlabel(qx)
    ax.set_ylabel(qy)
    ax.ticklabel_format(style="sci", scilimits=(-3, 4))   # MD ticks as x10^-4 instead of long decimals
    ax.set_title(f"correlation {np.corrcoef(x, y_)[0, 1]:.2f}")

    # legend with opaque, normal-size markers (the scatter points themselves are tiny and transparent)
    handles = [plt.Line2D([], [], marker="o", linestyle="", color="tab:green", markersize=6),
               plt.Line2D([], [], marker="x", linestyle="", color="black", markersize=8, markeredgewidth=2)]
    ax.legend(handles, [f"MH samples (n = {len(x)})", "DTI point estimate"], fontsize=9, loc="upper left")

plt.tight_layout()
plt.savefig("scatter_mh.png", dpi=300, bbox_inches="tight")
print("Saved scatter_mh.png")

plt.show()
