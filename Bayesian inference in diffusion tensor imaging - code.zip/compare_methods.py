"""
Compare the Metropolis-Hastings, VI and Laplace posteriors by plotting their histograms on top of each other.

The model and inference code is loaded straight from "Project code.ipynb", so this script
always uses the current implementation there. The notebook itself is only read, never changed.

Run from the project folder:  python compare_methods.py
"""

import json
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))   # notebook and cache/ are relative to this folder

NOTEBOOK = "Project_code_final.ipynb"
N_SAMPLES = 10000     # samples drawn from the VI and Laplace approximations
RECOMPUTE = False     # set to True to ignore the disk cache and refit all methods

# Metropolis-Hastings settings (gamma and nu tuned to give an acceptance rate of about 50%)
MH_N_SAMPLES = 50000
MH_GAMMA = 0.01
MH_NU = 2000
MH_BURN_IN = 500  


# Load the code cells from the notebook, skipping the pip install, the test cells and main()
with open(NOTEBOOK) as f:
    cells = json.load(f)["cells"]

for cell in cells:
    src = "".join(cell["source"])
    if cell["cell_type"] != "code" or src.lstrip().startswith("!"):
        continue
    if "TEST" in src or "def main(" in src:
        continue
    # skip cells that run an inference method (e.g. the trace-plot cell), only the definitions are needed
    if any(line.startswith(("metropolis_hastings(", "variational_inference(", "laplace_approximation("))
           for line in src.splitlines()):
        continue
    exec(src, globals())


# Data and DTI point estimate (the likelihood class needs gtab as a global)
y, point_estimate, gtab = get_preprocessed_data()
S0_init, evals_init, evecs_init = point_estimate
D_init = compute_D(evals_init, evecs_init).squeeze()
evec_principal = evecs_init[:, 0]

# Fit all methods (loaded from the cache if they have already been run with the same settings)
np.random.seed(0)
S0_mh, evals_mh, evecs_mh = metropolis_hastings(MH_N_SAMPLES, MH_GAMMA, MH_NU, force_recompute=RECOMPUTE)
np.random.seed(0)   # VI is fitted from seed 0, as in main()
posterior_vi = variational_inference(S0_init, D_init, force_recompute=RECOMPUTE)
posterior_laplace = laplace_approximation(S0_init, D_init, force_recompute=RECOMPUTE)

np.random.seed(0)
samples = {
    "MH": (S0_mh[MH_BURN_IN:], evals_mh[MH_BURN_IN:], evecs_mh[MH_BURN_IN:]),
    "VI": posterior_vi.rvs(size=N_SAMPLES),
    "Laplace": posterior_laplace.rvs(size=N_SAMPLES),
}


def summaries(S0, evals, evecs):
    # same quantities as in plot_results (the principal eigenvector is the last column,
    # since the eigenvalues of all three methods are in ascending order after burn-in)
    md = dti.mean_diffusivity(evals).squeeze()
    fa = dti.fractional_anisotropy(evals).squeeze()
    angle = 360/(2*np.pi) * np.arccos(np.clip(np.abs(np.dot(evecs[:, :, 2], evec_principal)), 0, 1))
    return {"S0": S0.squeeze(), "Mean diffusivity": md, "Fractional anisotropy": fa, "Acute angle": angle}


results = {method: summaries(*s) for method, s in samples.items()}
colors = {"MH": "tab:green", "VI": "tab:blue", "Laplace": "tab:orange"}
n_bins = np.floor(np.sqrt(N_SAMPLES)).astype(int)

fig, axes = plt.subplots(2, 2, figsize=(12, 10))

for ax, quantity in zip(axes.flat, results["VI"].keys()):
    # common bins so the histograms can be compared directly
    all_values = np.concatenate([results[m][quantity] for m in results])
    bins = np.linspace(np.percentile(all_values, 0.1), np.percentile(all_values, 99.9), n_bins)

    for method in results:
        values = results[method][quantity]
        # MH as an outline, so the two approximations can still be seen underneath it
        style = dict(histtype="step", linewidth=1.8) if method == "MH" else dict(alpha=0.45)
        ax.hist(values, bins=bins, density=True, color=colors[method],
                label=f"{method} (mean {values.mean():.3g}, sd {values.std():.2g})", **style)

    # DTI point estimate for reference (the angle is 0 by definition)
    point = {"S0": S0_init,
             "Mean diffusivity": dti.mean_diffusivity(evals_init),
             "Fractional anisotropy": dti.fractional_anisotropy(evals_init)}.get(quantity)
    if point is not None:
        ax.axvline(point, color="black", linestyle="--", linewidth=1, label="DTI point estimate")

    ax.set_xlabel(quantity)
    ax.set_ylabel("Density")
    ax.legend(fontsize=9)

plt.tight_layout()
plt.savefig("comparison_all_methods.png", dpi=300, bbox_inches="tight")
print("Saved comparison_all_methods.png")

# Table with means, standard deviations and 95% credible intervals (handy for the report)
print(f"\n{'':24s}{'method':>9s}{'mean':>12s}{'sd':>11s}{'2.5%':>12s}{'97.5%':>12s}")
for quantity in results["VI"]:
    for method in results:
        v = results[method][quantity]
        lo, hi = np.percentile(v, [2.5, 97.5])
        print(f"{quantity:24s}{method:>9s}{v.mean():12.4g}{v.std():11.3g}{lo:12.4g}{hi:12.4g}")

plt.show()
